import com.sun.jdi.IntegerValue;

public class Main {
    public static void main(String[] args) {
        System.out.println("Casting\n");


        System.out.println("Pegando um valor primitivo e colocando em variavel wrapper");
        Boolean status = true;
        System.out.println("Instanciando um objeto logico em wrapper");
        Boolean status1 = Boolean.TRUE;

        Character c = 'A';

        int num1 = 3;
        Integer num2 = 3;
        int num3 = Integer.valueOf(5);
        System.out.println(num3);
        float numero = 5f;
        float numero1 = Float.valueOf(6f);
        System.out.println(numero1);

        long cpf3 = Long.valueOf(12312312123l);
        System.out.println(cpf3);

    }
}